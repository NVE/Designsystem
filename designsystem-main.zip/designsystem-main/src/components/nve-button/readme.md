# nve-button



<!-- Auto Generated Below -->


## Properties

| Property  | Attribute | Description | Type                      | Default     |
| --------- | --------- | ----------- | ------------------------- | ----------- |
| `action`  | --        |             | `Function`                | `undefined` |
| `text`    | `text`    |             | `string`                  | `""`        |
| `variant` | `variant` |             | `"default" \| "outlined"` | `'default'` |


## Methods

### `handleClick() => Promise<void>`



#### Returns

Type: `Promise<void>`




----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
